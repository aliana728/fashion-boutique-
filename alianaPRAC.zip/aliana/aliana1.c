#include<stdio.h>
int main() {
    printf("enter radius: ");
    return 0;
}